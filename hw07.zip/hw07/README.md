Homework 7
==================
Search and Sort
------------------

Oh noes!  Billy's search and sort homeworks are horribly broken, can you fix them?

Go through and fix `search.py` and `sort.py` so they actually do what they are supposed to.  Make sure to feed both programs a bunch of input so you know they are working correctly.
